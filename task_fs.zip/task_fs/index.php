<?php
require 'header.php';
?>

<section class="main_content">

    <div class="container">
        <div class="jumbotron">
            <h1>Website Home Page</h1>
            <p>Created by Hermine Baghdasaryan.</p>
        </div>

    </div>
    <div class="poll_bar">
        <?php

        ?>
    </div>

</section>

<?php
require 'footer.php'
?>