$(document).ready(function () {


    var deleted_poll_id  = '';

    $("#registration_form" ).submit(function( event ) {

        event.preventDefault();

        var form_data = $(this).serialize();

        var first_name = $('input[name="first_name"]').val();
        var last_name  =  $('input[name="last_name"]').val();


        if ((first_name.search(/[^a-zA-Z]+/) === -1 && last_name.search(/[^a-zA-Z]+/) === -1 &&
            first_name.length > 1 && first_name.length < 30 && last_name.length > 1  && last_name.length < 30)) {

            $('#error_message').html('');


            $.ajax({
                url: 'functions.php',
                method: 'POST',
                data:form_data,

                success:function (data) {

                    var resp = $.parseJSON(data);
                    if(resp.success){
                        $('#sign_in_error').html(resp.success);
                        setTimeout(function () {
                            location.reload();
                        },2000)
                    }else{
                        $('#sign_in_error').html(resp.error);
                    }

                }
            })
        }else{
            $('#error_message').html('The first name or last name is incorrect');
        }

    });

    $(document).on('click' , '#log_in_button' ,function () {

        var email    = $('#LogInModal').find('input[name="email"]').val();
        var password = $('#LogInModal').find('input[name="password"]').val();

        $.ajax({
            url: 'functions.php',
            data:{
                email    : email,
                password : password,
                login    : true
            },
            method:'POST',
            success:function (data) {

                var resp = $.parseJSON(data);

                if(resp.error){
                    $('#login_error').html(resp.error);
                }else{
                    location.reload();
                }
            }
        })
    });


    // dinamic added inputs

    $('#add').click(function(){

        $('#dynamic_field').append('' +
            '<tr>' +
            '<td>' +
            '<input type="text" name="poll_option[]" placeholder="Poll option" class="form-control" required/>' +
            '</td>' +
            '<td>' +
            '<button type="button" name="remove"  class="btn btn-danger btn_remove">X</button>' +
            '</td>' +
            '</tr>');

    });

    // dinamic added inputs

    $(document).on('click', '.btn_remove', function(){
        $(this).closest("tr").remove();
    });

    $('#polls_add').find('.polls_add').on( 'click' ,  function(){

        $.ajax({

            url:"functions.php",
            method:"POST",
            data:$('#polls_add').serialize(),

            success: function(data) {
                var resp = $.parseJSON(data);
                var myStack = {"dir1":"down", "dir2":"right", "push":"bottom"};
                if(resp.error == undefined){
                    new PNotify({
                        title: "Over Here",
                        text: resp.success,
                        type: 'success',
                        addclass: "stack-bottomright",
                        stack: myStack
                    });

                    setTimeout(function () {
                        location.reload();
                    } , 1500);

                }else{
                    new PNotify({
                        title: "Over Here",
                        text: resp.error,
                        type: 'error',
                        addclass: "stack-bottomright",
                        stack: myStack
                    })
                }

            }
        });
    });


    $(function () {
        $.ajax({
            url: 'functions.php',
            data:{
                get_poll_items    : true,
                for_shows : true
            },
            method:'POST',
            success:function (data) {

                var resp = $.parseJSON(data);
                var str  = '';

                for(var i=0 ; i<resp.length ; i++){
                    str  += '<div class="well-sm clearfix">' +
                        '<div class="pol_title">' +
                        '<p>' + resp[i].poll_title + '</p>' +
                        '</div>';

                    for(var j=0; j < resp[i].options.length ; j++){
                        str += '<div class="block">' +
                            '<input type="radio" class="rad" id="options_id_'+resp[i].options_id[j] +'" value="'+resp[i].options_id[j] +'" name="'+resp[i].poll_id+'" />' +
                            '<label for="options_id_'+resp[i].options_id[j]+'">' +
                            resp[i].options[j] +
                            '</label>'+
                            '</div>'    ;
                    }

                    str  += '</div>';
                }

                $('.poll_bar').html(str);
            }
        });

        $.ajax({
            url: 'functions.php',
            data:{
                get_poll_items    : true,
                for_edit: true
            },
            method:'POST',
            success:function (data) {

                var resp = $.parseJSON(data);

                var str  = '';
                for( i=0 ; i<resp.length ; i++){
                    str  += '<div class="well-sm clearfix">' +
                        '<div class="pol_title">' +
                        '<p>'+ resp[i].poll_title +'</p>'+
                        '</div>';

                    for( j=0; j < resp[i].options.length ; j++){
                        str += '<div class="block">' +
                            '<label>'+resp[i].options[j]+'</label>'+
                            '</div>'    ;
                    }
                    str  += '<span class="edit glyphicon glyphicon-pencil" data_poll_id="'+resp[i].poll_id+'"></span>' +
                        '<span class="delete glyphicon glyphicon-trash" data_poll_title="'+ resp[i].poll_title +'" data_poll_id="'+resp[i].poll_id+'"></span>' +
                        '</div>';
                }

                $('#polls_edit').html(str);
            }
        })

    });

    $(document).on('change' , '.rad' , function () {

        var option_id  =  $(this).val();
        var poll_id    =  $(this).attr('name');
        var parent_element = $(this).closest('.well-sm');
        $.ajax({
            url: 'functions.php',
            data:{
                option_id : option_id,
                vote      : true
            },
            method:'POST',
            success: function(data) {

                var resp = $.parseJSON(data);
                var myStack = {"dir1":"down", "dir2":"right", "push":"bottom"};
                if(resp.error == undefined){

                    new PNotify({
                        title: "Over Here",
                        text: resp.success,
                        type: 'success',
                        addclass: "stack-bottomright",
                        stack: myStack
                    });

                    $.ajax({
                        url: 'functions.php',
                        method:'POST',
                        data:{
                            get_counts_of_votes : true,
                            poll_id      : poll_id
                        },
                        success: function (data) {

                            var resp = $.parseJSON(data);

                            var sum = resp[0].vote_count.reduce(add, 0);

                            var str  =  '<div class="pol_title">' +
                                '<p>' + resp[0].poll_title + '</p>' +
                                '</div>';


                            for(var j=0; j < resp[0].options.length ; j++){

                                var part = parseInt(resp[0].vote_count[j]) * 100 / sum;

                                str += '<div class="block">' +
                                    '<label>' +
                                    resp[0].options[j] +
                                    '</label>' +
                                    '<div class="diagram">' +
                                    '<span class="diagram" style="width: '+part+'%;"></span>' +
                                    '<i >' +
                                    part.toFixed(2)+'%'+
                                    '</i>' +
                                    '</div>' +
                                    '</div>'    ;
                            }
                                      parent_element.html(str);
                        }
                    })

                }else{
                    new PNotify({
                        title: "Over Here",
                        text: resp.error,
                        type: 'error',
                        addclass: "stack-bottomright",
                        stack: myStack
                    })
                }

            }
        })
    });

    $(document).on('click' , '.edit', function () {

        var data_poll_id = $(this).attr('data_poll_id');

        $.ajax({
            url: 'functions.php',
            data:{
                data_poll_id    : data_poll_id,
                for_edit: true
            },
            method:'POST',
            success:function (data) {

                var resp = $.parseJSON(data);

                // for modal
                var str_modal  = '';
                for(var i=0 ; i<resp.length ; i++){
                    str_modal  += '<div class="modal-header">' +
                        '<div class="well-sm clearfix">' +
                        '<div class="pol_title">' +
                        '<input type="text" value="' + resp[i].poll_title +'" class="p_title">'+
                        '</div>' +
                        ' </div>' +
                        '<div class="modal-body" id="append_block">';

                    for(var j=0; j < resp[i].options.length ; j++){
                        str_modal += '<div class="block">' +
                            '<input type="text" value="' + resp[i].options[j] +'" class="p_option p_option'+resp[i].options_id[j] +'" data_option_id="'+resp[i].options_id[j] +'" data_poll_id="'+resp[i].poll_id[j] +'">' +
                            '<span class="delete_option glyphicon glyphicon-trash"></span>'+
                            '</div>'    ;
                    }
                    str_modal  += ' </div>' +
                        '<span class="add_new_opton glyphicon glyphicon-plus"></span>' +
                        ' </div>' +
                        ' <div class="modal-footer">'+
                        '<input type="button" class="btn btn-default" value="Cancel" data-dismiss="modal">' +
                        '<input type="button" class="btn btn-default submit_edit" data_p_id="'+resp[i].poll_id+'" value="Submit changes">' +
                        '</div>';
                }
                // for modal

                $('#gen_block').html(str_modal);
                $('#edit_modal').modal('show');
            }
        })

    });

    $(document).on('click' , '.delete', function () {

        deleted_poll_id = $(this).attr('data_poll_id');
        var data_poll_title = $(this).attr('data_poll_title');

        $('#title_del_poll').html(data_poll_title);

        $('#delete_modal').modal('show');

    });

    $(document).on('click' , '#delete_submit', function () {

        $.ajax({
            url: 'functions.php',
            data:{
                deleted_poll_id    : deleted_poll_id,
                for_delete:  true
            },
            method:'POST',
            success:function (data) {

                var resp = $.parseJSON(data);

                var myStack = {"dir1":"down", "dir2":"right", "push":"bottom"};

                $('#delete_modal').modal('hide');

                if(resp.error == undefined){

                    new PNotify({
                        title: "Over Here",
                        text: resp.success,
                        type: 'success',
                        addclass: "stack-bottomright",
                        stack: myStack
                    });

                    setTimeout(function () {
                        location.reload();
                    },1500)
                }else{
                    new PNotify({
                        title: "Over Here",
                        text: resp.error,
                        type: 'error',
                        addclass: "stack-bottomright",
                        stack: myStack
                    })
                }

            }
        })


    });

    function add(a, b) {
        return parseInt(a) + parseInt(b);
    }

    $(document).on('click' , '.delete_option', function () {
        $(this).closest('.block').remove();
    });

    $(document).on('click' , '.add_new_opton', function () {

        var data_p_id = $(this).attr('data_p_id');

        var str_modal = '<div class="block">' +
            '<input type="text" value="" class="p_option">' +
            '<span class="delete_option  glyphicon glyphicon-trash"></span>'+
            '</div>';

        $('#append_block').append(str_modal);


    });

    $(document).on('click' , '.submit_edit' , function () {

        var options = [];
        var data_p_id = $(this).attr('data_p_id');

        $("#gen_block").find('.p_option').each(function(){

            if($(this).attr('data_option_id') == undefined){
                options.push({
                    new : true,
                    value: this.value
                });
            }else{
                options.push({
                    data_id : $(this).attr('data_option_id'),

                    value: this.value
                });
            }

        });

        var j_data = {
            title: $('#gen_block').find('.p_title').val(),
            options : options,
            data_id: data_p_id
        };


        $.ajax({
            type: "POST",
            url: "functions.php",
            dataType: "json",
            data: ({
                edited_data: j_data
            }),
            success:function (data) {

                var myStack = {"dir1":"down", "dir2":"right", "push":"bottom"};

                $('#edit_modal').modal('hide');

                if(data.error == undefined){

                    new PNotify({
                        title: "Over Here",
                        text: data.success,
                        type: 'success',
                        addclass: "stack-bottomright",
                        stack: myStack
                    });


                }else{

                    new PNotify({
                        title: "Over Here",
                        text: data.error,
                        type: 'error',
                        addclass: "stack-bottomright",
                        stack: myStack
                    });

                }
                setTimeout(function () {
                    location.reload();
                },1500)
            }

        });
    })
});